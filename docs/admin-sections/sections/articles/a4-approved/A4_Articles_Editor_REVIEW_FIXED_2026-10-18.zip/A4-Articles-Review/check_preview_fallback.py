#!/usr/bin/env python3
"""Offline regression: real HTML renders when scripting is disabled/stripped.
Requires existing Playwright and Chromium. No app, repository or network writes.
"""
import argparse, json, re
from pathlib import Path
from playwright.sync_api import sync_playwright

def run():
    ap=argparse.ArgumentParser()
    ap.add_argument('--browser',default='/usr/bin/chromium')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    source=Path(__file__).with_name('articles-reference.html').read_text(encoding='utf-8')
    results=[];requests=[];errors=[]
    def check(name,value):
        results.append({'name':name,'pass':bool(value)})
        assert value,name
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=args.browser,headless=True,args=['--no-sandbox'])
        for mode in ['disabled','stripped']:
            text=re.sub(r'<script\b[^>]*>[\s\S]*?</script\s*>','',source,flags=re.I) if mode=='stripped' else source
            for width,height in [(390,844),(414,896),(1536,1024)]:
                ctx=browser.new_context(viewport={'width':width,'height':height},java_script_enabled=mode!='disabled',locale='ru-RU')
                page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
                page.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http:','https:')) else None)
                page.set_content(text)
                label=f'{mode} {width}'
                check(label+' initial rows',page.locator('#main tbody tr').count()==8)
                check(label+' meaningful first paint',len(page.locator('#main').inner_text())>200)
                check(label+' no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
                check(label+' fallback explains read-only mode',page.locator('#a4-offline-note').is_visible())
                page.locator('#a4-offline-note a[href="#a4-static-material"]').click()
                check(label+' material link scrolls to content',page.locator('#a4-static-material').bounding_box()['y']<100)
                check(label+' article text visible',page.locator('#a4-static-material [contenteditable="false"]').is_visible())
                check(label+' static save disabled',page.locator('#a4-static-material button').first.is_disabled())
                if width==390:
                    page.screenshot(path=str(args.output/f'{mode}-material-mobile.png'))
                # Native details/anchors remain usable without JavaScript.
                page.locator('#a4-static-material a[href="#a4-static-seo"]').click()
                check(label+' SEO anchor works',page.locator('#a4-static-seo').bounding_box()['y']<100)
                check(label+' SEO fields visible',page.locator('#a4-static-seo input').first.is_visible())
                page.locator('#a4-static-seo a[href="#a4-static-list"]').first.click()
                check(label+' return link works',page.locator('#a4-static-list').bounding_box()['y']<100)
                ctx.close()
        check('no remote requests',not requests)
        check('no unexpected script errors',not errors)
        browser.close()
    report={'artifact':'A4 review HTML scripting fallback','checks':results,'pass':len(results),'fail':0,'requests':requests,'errors':errors,
      'method':'Playwright Chromium set_content; disabled JavaScript and removed script tags',
      'limitations':['Not tested on a physical iPhone or the ChatGPT iOS file viewer.', 'Managed browser blocks file:// navigation; trusted local bytes were supplied via set_content.', 'Browser connector offers tab reading only; local Playwright used.']}
    (args.output/'PREVIEW-FIX-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{len(results)} PASS / 0 FAIL; no-JavaScript/stripped-script modes only')

if __name__=='__main__':run()
