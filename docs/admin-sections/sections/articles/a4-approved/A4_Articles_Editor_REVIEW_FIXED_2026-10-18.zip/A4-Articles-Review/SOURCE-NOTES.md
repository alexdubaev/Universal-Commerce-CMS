# Источники и границы подготовки

Дата подготовки: 2026-10-18. Прочитанная ветка main: `9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7`. Никаких GitHub writes, запуска Directus или чтения секретов этой подготовкой не выполнялось. Анализ кода не доказывает текущее состояние локального контейнера.

Проверенные первичные исходники (доступ через GitHub-коннектор):
- [Исторический план articles](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/docs/admin-sections/sections/articles/TZ.md)
- [27 полей в статической карте](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/docs/admin-sections/sections/articles/fields.json)
- [Редакционный контентный процесс](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/docs/content/articles.md)
- [Public adapter и даты](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/storefront/lib/articles.ts)
- [Безопасный public HTML renderer](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/storefront/components/articles/ArticleContent.tsx)
- [Public detail и metadata](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/storefront/app/articles/[slug]/page.tsx)
- [Versions allowlist](https://github.com/alexdubaev/Universal-Commerce-CMS/blob/9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7/directus/extensions/commerce-api/src/versions.mjs)

Разрешены противоречия старого плана: статьи не singleton; ArticleContent здесь HTML, не active block consumer; page_sections не article M2A; versions pages/home_page не articles. Жёсткое добавление всех старых полей без проверки потребителя не повторяется.

A3 визуальная база: предоставленный пользователю `A3-Pages-Review/pages-reference.html` и его `pages-editor-desktop.png`. Общие CSS tokens и контекст оболочки переиспользованы локально в макете. Новый продуктовый код репозитория не создавался.

Автор текста/данные не подтверждаются демонстрацией. Изображения обложки отсутствуют намеренно. Демонстрационные статьи относятся только к макету, не импортируются в CMS.
