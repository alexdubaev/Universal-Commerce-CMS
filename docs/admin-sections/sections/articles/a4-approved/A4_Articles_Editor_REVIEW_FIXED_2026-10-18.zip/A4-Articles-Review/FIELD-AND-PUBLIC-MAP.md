# A4 — карта полей и потребителей

Статический read-only анализ main на 9a0b55fd17f2b7f58d2889ff0c2e4e033ce64ab7, 18.10.2026. Это не выгрузка live schema, не проверка прав и не обещание подключённости каждого поля.

| Поля | Место UI | Подтверждённый смысл / ограничение |
|---|---|---|
| title, slug, excerpt | Основное / список | Public summary/detail; title→H1, excerpt→вступление. Slug Unicode letters/numbers, _/-, 1–160, без slash по текущему адаптеру. |
| content | Материал | Канонический HTML public текста. Не новый block editor. |
| content_blocks | readonly disclosure | ProseMirror JSON хранится; public article adapter не читает. Не конвертировать/чистить. |
| editor_nodes | readonly technical | M2A alias→articles_editor_nodes; не parent CAS и не page_sections. |
| cover_image, image_alt | Материал / справа | Public cover; file UUID, public publication+folder protection. |
| published_at, status | Основное / контекст | Обязательная дата + draft/published/archived. Дата future ограничивает public visibility. |
| author | Основное | Public author/metadata только если задан. Не создавать фиктивное имя. |
| reviewer, reading_time_minutes | Редакционные данные | Текущий summary/detail adapter не запрашивает. |
| category_label | Основное, список/фильтр | Свободная рубрика. Не category relation и не публичная фильтрация. |
| sources | Связи / disclosure | JSON редакционных источников; public adapter не запрашивает. Форма live JSON требует сверки. |
| related_categories, related_products | Связи | JSON string arrays UUID/slug. Витрина читает до 8 каждого типа; public-only linked records. Не мутировать catalogue. |
| is_featured, sort_order | Связи / редакция | Не используются проверенным public list: он sort=-published_at,slug. Нельзя подписывать «На главной» без отдельной интеграции. |
| seo_title, seo_description | SEO | Реальные scalar metadata, fallback title/excerpt. |
| og_image | SEO | OG fallback→cover_image. |
| seo | Native SEO / disclosure | JSON сохраняется. Не читается непосредственно текущим article detail projection; отдельно сверять hooks↔scalar проекции. |
| translations | Дополнительно | JSON; локализация storefront не подключается этим UI. |
| id, created_at, updated_at | Дополнительно | Readonly технические; updated_at не редакционная дата обновления. |

Список: существующие status/title/slug/category_label/published_at/is_featured/updated_at, ограниченная страница, без загрузки content всех статей. Админский native path и public gateway имеют разные limits: не переносить 24 public в native list без проверки и не расширять gateway ради UI.

## Маршруты

Admin: `/admin/product-editor/sections/articles`, `/:id`, `/+` внутри этого namespace. Optional ID/пустая строка должны различать список и карточку корректно.

Public: `/articles`, `/articles/<encoded-slug>`. Generic A3 `/[slug]` не заменяет этот маршрут. `status=published` + валидная наступившая дата обязательны. Canonical строится из подтверждённого site URL и /articles/slug. Нет отдельного физического is_indexable/canonical_url у articles в исследованном snapshot — не копировать SEO переключатели pages.

Материалы связей с каталогом разрешаются как string ID или slug. Полный контракт — getArticleRelatedLinks в storefront/lib/articles.ts. ArticleContent HTML ссылок имеет собственный узкий allowlist; это отдельная проверка, не то же самое, что related links.

## Решение подготовки

Core A4 даёт работающие текст/обложку/date/status/scalar SEO/каталожные ссылки. Неиспользуемые сейчас редакционные поля не скрываются безвозвратно, но не получают обещаний влияния на сайт. Новая публичная функциональность требует отдельного scoped задания, а не незаметного расширения A4.
