```text
# HANDOFF — A4 Articles Editor

Итог: implemented/partial/blocked. Какие core сценарии реально доступны.
Git: baseline SHA, task branch, commits, PR, final main SHA, merge/tree verification, cleanup.
Текст: source content, native interface, сохранность content_blocks/editor_nodes, формат/preview ограничения.
Публикация: create required fields, draft/date/future/published/archive, timezone, live effects, no-version boundary.
Связи/SEO: реальные потребители полей и неподключённые настройки; что сохраняется без потери JSON.
Параллельность: shared owner, принятые exports/commits, registry сохранён, зависимости A2/A3.
Проверки: команды, PASS/FAIL, actual API/roles vs controlled responses, реальные desktop/mobile PNG и review.
Runtime: tested browser bundle / installed bundle / production — указать отдельно, версии и окружения.
Deploy: результат/rollback либо конкретный DEPLOY BLOCKED.
Данные: owned fixture journals/ID cleanup, 0 остатков либо точные неочищенные ID; чужие records untouched.
Ограничения: не обещать работающих blocks/versions/public fields без подтверждения.
Следующий шаг: одна отдельная задача. Ничего следующего не начиналось.

Правила следующему агенту:
Одна задача, свежая временная ветка от origin/main, отдельный worktree;
параллельно только независимые файлы, shared writer и runtime по очереди;
functional AND visual acceptance перед автономными push/PR/review/merge;
deploy только подтверждённый безопасный; cleanup только своего;
все ТЗ/промпты/HANDOFF в копируемых блоках.
```
