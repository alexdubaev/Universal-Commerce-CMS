#!/usr/bin/env python3
"""Offline A4 mock checks; never contacts Directus or edits repository/runtime data.
Run: python check_reference.py --browser /path/to/chromium --output /tmp/a4-check
Requires an existing Python Playwright installation. No automatic installation.
"""
import argparse, json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

def run():
    ap=argparse.ArgumentParser();ap.add_argument('--browser',default=None);ap.add_argument('--output',type=Path,default=Path.cwd()/'a4-reference-output');args=ap.parse_args()
    source=Path(__file__).with_name('articles-reference.html');args.output.mkdir(parents=True,exist_ok=True)
    results=[];issues=[];screens=[];network=[]
    def check(name,yes):
        results.append({'name':name,'pass':bool(yes)})
        if not yes: raise AssertionError(name)
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,**({'executable_path':args.browser} if args.browser else {}))
        context=browser.new_context(locale='ru-RU',viewport={'width':1536,'height':1024},device_scale_factor=1)
        context.on('request',lambda r:network.append(r.url) if r.url.startswith(('https:','http:')) else None)
        def fresh(route='list',w=1536,h=1024):
            page=context.new_page();page.set_viewport_size({'width':w,'height':h});page.on('pageerror',lambda e:issues.append(str(e)))
            # Render trusted local source directly; managed browser disallows file/local HTTP navigation.
            page.set_content(source.read_text(encoding='utf-8'))
            page.evaluate('(h)=>{location.hash=h}',route);page.wait_for_timeout(30)
            return page
        page=fresh()
        count=lambda:page.locator('tbody tr').count()
        check('list renders eight demonstration records',count()==8)
        check('toolbar height 40px desktop',page.locator('#search').bounding_box()['height']==40)
        check('list has no document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        page.locator('#search').fill('Где найти');check('search finds matching title',count()==1)
        page.locator('#search').fill('не-существует');check('separate empty state',page.get_by_text('Статьи не найдены',exact=True).count()==1)
        page.locator('[data-action="reset-all"]').click();check('reset restores rows',count()==8)
        page.locator('#status-filter').select_option('draft');check('draft status filter',count()==3)
        page.locator('#status-filter').select_option('')
        page.locator('[data-action="filters"]').click();page.locator('#filter-rubric').select_option(label='Практика')
        check('pending filters do not apply',count()==8)
        page.keyboard.press('Escape');check('escape closes modal',not page.locator('#modal').is_visible())
        check('escape restores trigger focus',page.evaluate('document.activeElement.dataset.action')=='filters')
        check('cancel leaves query unchanged',page.evaluate('A4_DEMO.state().query.rubric')=='')
        page.locator('[data-action="filters"]').click();page.locator('#filter-featured').select_option('true');page.locator('[data-action="apply-filters"]').click()
        check('filter apply yields recommended records',count()==2)
        check('applied filter has removable chip',page.locator('[data-action="clear-featured"]').count()==1)
        page.locator('[data-action="clear-featured"]').click();check('remove chip restores results',count()==8)
        check('fourteen combined sorting options',page.locator('#sort option').count()==14)
        page.locator('#sort').select_option('title');ascending=page.locator('tbody .article-link').all_text_contents()
        page.locator('#sort').select_option('-title');check('sort direction reverses rows',page.locator('tbody .article-link').all_text_contents()==ascending[::-1])
        page.locator('.demo-options summary').click();page.locator('[data-action="many"]').click();check('bounded mock page size 25',count()==25)
        page.locator('[data-action="next"]').click();check('pagination remaining five',count()==5)
        page.close();page=fresh('edit?tab=material')
        check('one material textbox only',page.locator('#article-body[contenteditable="true"]').count()==1)
        structural=page.evaluate('JSON.stringify(A4_DEMO.state().current.content_blocks)')
        page.locator('#article-body').fill('Мой текст для проверки сохранности между вкладками.')
        page.locator('[data-tab="main"]').click();page.locator('#f-excerpt').fill('Моё описание')
        page.locator('[data-tab="seo"]').click();check('text retained across tabs','Мой текст' in page.evaluate('A4_DEMO.state().current.content'))
        page.locator('.side-link.active').click();check('sidebar exit protects dirty input',page.locator('#modal').is_visible());page.keyboard.press('Escape')
        page.locator('#f-seo_title').fill('Проверяемый заголовок');check('SEO hint updates',page.locator('#serp-title').inner_text()=='Проверяемый заголовок')
        page.locator('#save').click();page.wait_for_timeout(280)
        check('save retains draft state',page.evaluate('A4_DEMO.state().current.status')=='draft')
        check('save clears dirty state only after acknowledgement',not page.evaluate('A4_DEMO.state().dirty'))
        check('structured content left unchanged',page.evaluate('JSON.stringify(A4_DEMO.state().current.content_blocks)')==structural)
        page.locator('[data-tab="material"]').click();page.locator('[data-action="pick-cover_image"]').click();page.locator('[data-action="file-cover_image"]').click()
        check('synthetic media selection staged',page.evaluate('A4_DEMO.state().current.cover_image')=='demo-image')
        page.locator('[data-action="remove-cover_image"]').click();check('unlink removes relation only',page.evaluate('A4_DEMO.state().current.cover_image') is None)
        page.locator('[data-action="focus"]').click();check('writing mode hides aside',not page.locator('.sideinfo').is_visible())
        page.locator('[data-action="focus"]').click()
        page.locator('[data-action="reading"]').click();check('reading view is explicitly local',page.get_by_text('ЧТЕНИЕ · МАКЕТ',exact=True).count()==1)
        page.close();page=fresh('edit?tab=main')
        page.locator('#f-published_at').fill('21.10.2026, 10:00');page.locator('#save').click();page.wait_for_timeout(250)
        check('future date alone does not publish',page.evaluate('A4_DEMO.state().current.status')=='draft')
        page.locator('[data-action="status"]').click();page.locator('input[value="published"]').check();page.locator('[data-action="status-confirm"]').click()
        check('future-published derived availability',page.locator('.heading-line .status').inner_text()=='Ожидает даты')
        page.close();page=fresh('edit?id=demo-2&tab=main')
        page.locator('#f-excerpt').fill('Изменения опубликованного материала');page.locator('#save').click()
        check('published save requires acknowledgement',page.get_by_text('Обновить опубликованную запись?',exact=True).count()==1)
        page.locator('#modal [data-action="close"]').last.click();check('cancel preserves staged data',page.evaluate('A4_DEMO.state().dirty'))
        page.close();page=fresh('edit?conflict=1')
        check('conflict blocks save',page.locator('#save').is_disabled())
        before=page.evaluate('A4_DEMO.state().current.content');page.locator('[data-action="compare"]').click();page.locator('[data-action="keep"]').click()
        check('reconciliation retains text',page.evaluate('A4_DEMO.state().current.content')==before)
        check('reconciliation does not auto-save',page.evaluate('A4_DEMO.state().dirty'))
        page.close();page=fresh('edit?readonly=1&tab=material')
        check('readonly disables text',page.locator('#article-body').get_attribute('contenteditable')=='false')
        check('readonly disables save',page.locator('#save').is_disabled())
        page.close();page=fresh('new')
        page.locator('#f-title').fill('Новая демонстрационная статья');page.locator('#save').click()
        check('required fields validated',page.locator('.field-error').count()>=2)
        page.locator('#f-slug').fill('new-demo-article');page.locator('#f-excerpt').fill('Краткий вводный текст')
        page.locator('[data-tab="material"]').click();page.locator('#article-body').fill('Полный текст новой демонстрационной статьи.');page.locator('#save').click();page.wait_for_timeout(250)
        check('create returns demonstration ID',bool(page.evaluate('A4_DEMO.state().current.id')))
        check('create defaults to draft',page.evaluate('A4_DEMO.state().current.status')=='draft')
        check('no automatic content block conversion',page.evaluate('A4_DEMO.state().current.content_blocks') is None)
        page.close()
        # Fresh reference screenshots, with no dependency on previous interaction state.
        shots=[('articles-list-desktop','list',1536,1024),('articles-editor-desktop','edit?tab=material',1536,1024),('articles-main-desktop','edit?tab=main',1536,1024),('articles-seo-desktop','edit?tab=seo',1536,1024),('articles-relations-desktop','edit?tab=relations',1536,1024),('articles-create-desktop','new',1536,1024),('articles-conflict-desktop','edit?conflict=1',1536,1024),('articles-list-mobile','list',390,844),('articles-editor-mobile','edit?tab=material',390,844),('articles-main-mobile','edit?tab=main',390,844),('articles-editor-1024','edit?tab=material',1024,900)]
        for name,route,w,h in shots:
            page=fresh(route,w,h);check(name+' has no document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            page.screenshot(path=str(args.output/(name+'.png')));screens.append(name+'.png');page.close()
        for w,h,suffix in [(1536,1024,'desktop'),(390,844,'mobile')]:
            page=fresh('list',w,h);page.locator('[data-action="filters"]').click();page.screenshot(path=str(args.output/f'articles-filters-{suffix}.png'));screens.append(f'articles-filters-{suffix}.png');page.close()
        page=fresh('list',390,844);check('mobile input height 44px',page.locator('#search').bounding_box()['height']==44);page.close()
        check('no JavaScript exceptions',len(issues)==0);check('no external requests',len(network)==0)
        browser.close()
    report={'artifact':'A4 offline visual reference','not_cms_acceptance':True,'method':'Chromium page.set_content with local HTML; no navigation to CMS','checks':results,'passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results),'screenshots':screens,'errors':issues,'external_requests':network}
    (args.output/'REFERENCE-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"{report['passed']} PASS / {report['failed']} FAIL; {len(screens)} screenshots; offline mock only")

if __name__=='__main__':run()
