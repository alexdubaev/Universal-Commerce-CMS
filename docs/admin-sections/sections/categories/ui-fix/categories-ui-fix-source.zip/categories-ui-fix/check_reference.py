from pathlib import Path
import json
import os
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).parent
url='offline-reference'
results=[]
with sync_playwright() as p:
    executable=os.environ.get('PLAYWRIGHT_CHROMIUM_EXECUTABLE') or shutil.which('chromium')
    launch={'headless':True}
    if executable: launch['executable_path']=executable
    browser=p.chromium.launch(**launch)
    page=browser.new_page(viewport={'width':1536,'height':1024},device_scale_factor=1)
    def load(href):
        query=href.split('?',1)[1] if '?' in href else ''
        html=(root/'categories-reference.html').read_text().replace('new URLSearchParams(location.search)', 'new URLSearchParams('+json.dumps(query)+')')
        page.set_content(html,wait_until='load')
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    load(url)
    page.screenshot(path=str(root/'categories-desktop.png'),full_page=False)
    assert page.locator('tbody tr').count()==25
    first_y=page.locator('tbody tr').first.bounding_box()['y']
    results.append({'check':'Desktop 1536×1024: first row y','value':first_y,'pass':first_y<=250})
    assert first_y<=250
    for width in [1536,1024,874,390,320]:
        page.set_viewport_size({'width':width,'height':844 if width<600 else 1024})
        load(url)
        width_data=page.evaluate('({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
        assert width_data['scroll']==width_data['client'],(width,width_data)
        if width==390:page.screenshot(path=str(root/'categories-mobile.png'),full_page=False)
        results.append({'check':f'No document overflow: {width}px','pass':True})
    page.set_viewport_size({'width':1536,'height':1024})
    load(url)
    page.get_by_role('searchbox',name='Поиск категорий',exact=True).fill('двигатель')
    assert page.locator('tbody tr').count()==1
    results.append({'check':'Search filters sample rows','pass':True})
    page.locator('#search').fill('')
    page.locator('#status').select_option('draft')
    assert page.locator('tbody tr').count()==3
    results.append({'check':'Status filter','pass':True})
    page.locator('#status').select_option('')
    page.locator('#sort').select_option('title')
    titles=page.locator('.category-name').all_text_contents()
    assert titles[0]=='Архивные категории'
    results.append({'check':'Sort options','pass':True})
    page.locator('#sort').select_option('-updated_at')
    page.locator('#filters-open').click()
    page.locator('#parent-trigger').click()
    page.locator('#parent-search').fill('John Deere')
    page.get_by_role('button',name='Запчасти John Deere',exact=True).click()
    page.locator('#home').select_option('true')
    page.screenshot(path=str(root/'categories-filters.png'),full_page=False)
    page.get_by_role('button',name='Применить',exact=True).click()
    assert page.locator('tbody tr').count()==4
    assert page.locator('#filter-count').inner_text()=='2'
    assert page.locator('#filters-dialog').get_attribute('open') is None
    assert page.locator('#filters-open').evaluate('(el)=>el===document.activeElement')
    results.append({'check':'Parent/home filters; apply; chips; focus return','pass':True})
    page.locator('#clear-all').click()
    page.locator('#next').click()
    assert page.locator('tbody tr').count()==3
    assert page.locator('#page-label').inner_text()=='2 / 2'
    results.append({'check':'Pagination','pass':True})
    page.locator('#prev').click()
    page.locator('.category-name').first.click()
    assert page.locator('#detail-dialog').is_visible()
    page.keyboard.press('Escape')
    assert not page.locator('#detail-dialog').is_visible()
    results.append({'check':'Read-only demo details; Escape','pass':True})
    for width in [1536,390]:
        page.set_viewport_size({'width':width,'height':1024 if width>600 else 844})
        load(url+'?stress=1')
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
        if width==1536:page.screenshot(path=str(root/'categories-long-values.png'),full_page=False)
        results.append({'check':f'Long UUID and parent names {width}px','pass':True})
    for state,expected in [('readonly','Только просмотр.'),('empty','Категории не найдены'),('error','Не удалось загрузить категории')]:
        load(url+'?state='+state)
        assert expected in page.locator('body').inner_text()
        if state=='readonly':assert not page.locator('#create').is_visible()
        results.append({'check':'Demo state '+state,'pass':True})
    load(url)
    page.locator('#filters-open').click()
    page.screenshot(path=str(root/'categories-filters-mobile.png'),full_page=False)
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    page.keyboard.press('Escape')
    assert page.locator('#filters-open').evaluate('(el)=>el===document.activeElement')
    results.append({'check':'Mobile filter dialog; Escape; focus return','pass':True})
    assert not errors,errors
    results.append({'check':'No JavaScript page errors','pass':True})
    browser.close()
(root/'reference-checks.json').write_text(json.dumps({'scope':'Offline visual reference only. No Directus/runtime/product acceptance.', 'browser':'System Chromium via Playwright set_content for offline HTML; file and localhost navigation blocked by environment policy. No connection to Directus.', 'checks':results},ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False,indent=2))
