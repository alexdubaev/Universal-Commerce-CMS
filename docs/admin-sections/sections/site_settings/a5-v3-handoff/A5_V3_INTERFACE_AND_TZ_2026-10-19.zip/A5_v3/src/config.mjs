/** Physical field names follow the verified site_settings blueprint. Values are synthetic. */
export const FIELD = {
 company_name:{label:'Название магазина',group:'company',required:true,help:'В подвале и подписях сайта. Изменение названия не заменяет логотип.'},
 legal_name:{label:'Юридическое наименование',group:'company',help:'Полное название организации. Используется в сведениях для поисковых систем.'},
 inn:{label:'ИНН',group:'company',width:'short',numeric:true},
 kpp:{label:'КПП',group:'company',width:'short',numeric:true},
 ogrn:{label:'ОГРН',group:'company',width:'medium',numeric:true},
 legal_address:{label:'Юридический адрес',group:'company',type:'textarea',rows:2},
 vat_info:{label:'Информация о НДС',group:'company',help:'Используется на странице «Оплата».'},
 requisites_url:{label:'Ссылка на реквизиты',group:'company',type:'url',notConnected:true},
 documents_url:{label:'Ссылка на документы',group:'company',type:'url',notConnected:true},
 phone:{label:'Телефон для покупателей',group:'contacts',type:'tel',required:true,help:'В шапке, подвале и на странице «Контакты».'},
 email:{label:'Электронная почта',group:'contacts',type:'email',required:true,help:'Публичный адрес для обращений покупателей.'},
 city:{label:'Город',group:'contacts'},
 address:{label:'Адрес офиса или склада',group:'contacts',type:'textarea',rows:2},
 working_hours:{label:'Время работы',group:'contacts'},
 delivery_region:{label:'Регион доставки',group:'contacts',help:'Используется на странице «Доставка».'},
 messengers:{label:'Мессенджеры',group:'contacts',type:'list',notConnected:true},
 social_links:{label:'Социальные сети',group:'contacts',readonly:true,notConnected:true},
 logo:{label:'Логотип',group:'appearance',type:'file',notConnected:true,help:'Выберите свой файл. Образец логотипа не подставляется.'},
 favicon:{label:'Значок вкладки браузера',group:'appearance',type:'file',notConnected:true,help:'Небольшой квадратный значок рядом с названием сайта.'},
 company_image:{label:'Изображение компании',group:'appearance',type:'file',notConnected:true},
 primary_color:{label:'Основной цвет',group:'appearance',type:'color',notConnected:true},
 accent_color:{label:'Акцентный цвет',group:'appearance',type:'color',notConnected:true},
 primary_cta_text:{label:'Текст основной кнопки',group:'appearance',notConnected:true},
 primary_cta_url:{label:'Ссылка основной кнопки',group:'appearance',type:'url',notConnected:true},
 footer_text:{label:'Описание компании в подвале',group:'appearance',type:'textarea',rows:2},
 footer_disclaimer:{label:'Примечание в подвале',group:'appearance',type:'textarea',rows:2},
 seo_title:{label:'Заголовок по умолчанию',group:'search'},
 seo_description:{label:'Описание по умолчанию',group:'search',type:'textarea',rows:3},
 og_title:{label:'Заголовок карточки ссылки',group:'search'},
 og_description:{label:'Описание карточки ссылки',group:'search',type:'textarea',rows:3},
 default_og_image:{label:'Обложка карточки ссылки',group:'search',type:'file'},
};
export const TABS=[['overview','Обзор'],['company','Компания'],['contacts','Контакты'],['appearance','Оформление'],['search','Поиск и соцсети']];
export const EDITABLE=Object.keys(FIELD).filter(key=>!FIELD[key].readonly);
export const INITIAL={
 id:'demo-singleton',created_at:'2026-10-19T12:00:00.000Z',updated_at:'demo-1',
 company_name:'Магазин запчастей',legal_name:'ООО «Пример»',
 phone:'+7 (000) 000-00-00',email:'office@example.test',city:'Санкт-Петербург',address:null,
 working_hours:'Пн–Пт, 09:00–18:00',delivery_region:'Россия',
 inn:null,kpp:null,ogrn:null,legal_address:null,vat_info:'Работаем с НДС',
 requisites_url:null,documents_url:null,messengers:[],social_links:null,
 logo:null,favicon:null,company_image:null,primary_color:'#2563eb',accent_color:'#f59e0b',
 primary_cta_text:'Отправить заявку',primary_cta_url:'/request',
 footer_text:'Поставка запасных частей для спецтехники.',
 footer_disclaimer:'Условия поставки и оплаты согласовываются с менеджером.',
 seo_title:null,seo_description:null,og_title:null,og_description:null,default_og_image:null,
 commerce_profile:{managed:'outside-a5'},yandex_metrica_id:null,gtm_id:null,translations:{},
};
export function validateValues(values, baseline, dirty) {
 const errors={};
 for(const key of dirty){
  const field=FIELD[key];if(!field||field.readonly)continue;
  const value=values[key], text=typeof value==='string'?value.trim():'';
  if(field.required&&!text){errors[key]='Заполните это поле.';continue;}
  if(field.type==='email'&&text&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text))errors[key]='Укажите адрес вида name@example.ru.';
  if(field.type==='url'&&text&&!safeHref(text))errors[key]='Укажите адрес страницы, например /contacts, или полную ссылку с https://.';
  if(field.type==='color'&&text&&!/^#[0-9a-f]{6}$/i.test(text))errors[key]='Укажите цвет в формате #2563EB.';
  if(key==='messengers'&&(!Array.isArray(value)||value.some(item=>!item?.label?.trim()||!safeHref(item.url))))errors[key]='У каждой строки должны быть название и безопасная ссылка.';
 }
 return errors;
}
export function safeHref(value){
 if(typeof value!=='string'||!value.trim())return false;
 const text=value.trim();if(/[\u0000-\u0020\u007f\\]/.test(text))return false;
 if(text.startsWith('/')&&!text.startsWith('//'))return true;
 try {const url=new URL(text);return ['https:','http:'].includes(url.protocol)&&Boolean(url.hostname)&&!url.username&&!url.password;}catch{return false;}
}
