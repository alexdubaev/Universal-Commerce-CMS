/** State for the offline design prototype only. Native A5 must reuse A0 createEditorState. */
const clone = value => structuredClone(value);
const equal = (a, b) => {
  if (a === b) return true;
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const aa=Object.keys(a).sort(), bb=Object.keys(b).sort();
  return aa.length===bb.length && aa.every((key,i)=>key===bb[i] && equal(a[key],b[key]));
};
export function createEditor(initial, allowedFields) {
  const allowed=new Set(allowedFields);
  let baseline=clone(initial), draft=clone(initial), phase='idle', readonly=false;
  const dirtyFields=()=>[...allowed].filter(key=>!equal(baseline[key],draft[key]));
  const canSave=()=>!readonly && ['idle','error'].includes(phase) && dirtyFields().length>0;
  const validRecord=record=>record && typeof record==='object' && !Array.isArray(record)
    && record.id===baseline.id && Object.hasOwn(record,'updated_at');
  function adopt(record) { baseline=clone({...baseline,...record});draft=clone(baseline);phase='idle'; }
  return {
    values:()=>clone(draft), baseline:()=>clone(baseline), dirtyFields,
    status:()=>phase, isReadonly:()=>readonly, canSave,
    setReadonly(value){readonly=Boolean(value);},
    change(key,value){
      if(readonly || !['idle','error'].includes(phase) || !allowed.has(key)) return false;
      draft[key]=clone(value);phase='idle';return true;
    },
    payload(){
      const changed=dirtyFields();
      return {expected:{id:baseline.id,updated_at:baseline.updated_at,...Object.fromEntries(changed.map(key=>[key,clone(baseline[key])]))},
        changes:Object.fromEntries(changed.map(key=>[key,clone(draft[key])]))};
    },
    beginSave(){if(!canSave())return false;phase='saving';return true;},
    acknowledge(record){
      if(phase!=='saving' || !validRecord(record) || dirtyFields().some(key=>!Object.hasOwn(record,key)||!equal(record[key],draft[key]))){phase='uncertain';return false;}
      adopt(record);return true;
    },
    discard(){if(!['idle','error'].includes(phase))return false;draft=clone(baseline);phase='idle';return true;},
    conflict(){phase='conflict';},
    uncertain(){phase='uncertain';},
    fail(){phase='error';},
    rebase(record,choices){
      const dirty=dirtyFields();
      if(!validRecord(record) || dirty.some(key=>!Object.hasOwn(record,key)||!['local','remote'].includes(choices[key])))return false;
      const own=clone(draft);adopt(record);
      for(const key of dirty)if(choices[key]==='local')draft[key]=own[key];
      return true;
    },
    checkRemote(record){
      if(!validRecord(record))return false;
      if(dirtyFields().every(key=>Object.hasOwn(record,key)&&equal(record[key],draft[key]))){adopt(record);return true;}
      phase='conflict';return false;
    }
  };
}
