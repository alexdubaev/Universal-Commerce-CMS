import {createEditor} from './model.mjs';
import {FIELD,TABS,EDITABLE,INITIAL,validateValues} from './config.mjs';

// This entry point has no network transport. All writes are local demonstrations.
const $=(selector,root=document)=>root.querySelector(selector);
const $$=(selector,root=document)=>[...root.querySelectorAll(selector)];
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const copy=value=>structuredClone(value);
const PATHS={
 grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
 home:'<path d="m3 10 9-7 9 7v10H15v-6H9v6H3z"/>',
 box:'<path d="m3 7 9-4 9 4v11l-9 4-9-4zM3 7l9 4 9-4M12 11v11M7.5 5l9 4"/>',
 file:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6M9 16h6"/>',
 article:'<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 7h8M8 11h8M8 15h5"/>',
 settings:'<path d="M4 7h16M4 17h16"/><rect x="8" y="4" width="4" height="6" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="14" width="4" height="6" rx="1" fill="currentColor" stroke="none"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7v.2"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4M12 17v.1"/>',
 menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
 close:'<path d="m6 6 12 12M18 6 6 18"/>',
 chevron:'<path d="m9 5 7 7-7 7"/>',
 back:'<path d="m10 5-7 7 7 7M3 12h18"/>',
 picture:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/>',
 plus:'<path d="M12 4v16M4 12h16"/>',
 check:'<path d="m4 12 5 5L20 6"/>',
 trash:'<path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/>',
};
const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">${PATHS[name]||PATHS.info}</svg>`;
const mountIcons=()=>$$('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});
let remoteRecord=copy(INITIAL), editor=createEditor(remoteRecord,EDITABLE), route='overview', inlineGroup=null;
let mode='normal',outcome='success',version=1,errors={},problem=null,comparedRecord=null,toastTimer=null;
let previewSearch=false,previewShare=false,confirmAction=null,confirmFocus=null,aboutFocus=null;
let selectedAsset=0;
const assets=new Map();
const fieldsInGroup=group=>Object.keys(FIELD).filter(key=>FIELD[key].group===group);
const isWritable=key=>!['readonly','denied','missing','multiple','loadError'].includes(mode)
  && (mode!=='partial'||key==='phone') && EDITABLE.includes(key) && ['idle','error'].includes(editor.status());
const dis=key=>isWritable(key)?'':'disabled';
const val=key=>editor.values()[key];
const stringValue=value=>typeof value==='string'?value:'';
const formatValue=(key,value)=>{
 if(value===null||value===undefined||value==='')return 'Не указано';
 if(FIELD[key]?.type==='file')return assets.get(value)?.name||'Файл выбран';
 if(Array.isArray(value))return value.length?`${value.length} записей`:'Не добавлены';
 return typeof value==='object'?'Существующие данные':String(value);
};
function note(text,warning=false,compact=false){return `<div class="info-note${warning?' warning':''}${compact?' compact':''}">${icon('info')}<p>${text}</p></div>`;}
function field(key,options={}){
 const d=FIELD[key],value=val(key),id=`input-${key}`,hint=d.help||'',error=errors[key]||'';
 if(d.type==='file')return assetField(key);
 if(d.type==='list')return messengerField();
 const attributes=`id="${id}" data-field="${key}" ${d.required?'required':''} ${dis(key)} aria-invalid="${error?'true':'false'}" aria-describedby="help-${key} error-${key}" ${d.numeric?'inputmode="numeric"':''}`;
 let control;
 if(d.type==='textarea')control=`<textarea ${attributes} rows="${d.rows||2}">${esc(value)}</textarea>`;
 else if(d.type==='color')control=`<div class="color-control"><input type="color" aria-label="Выбрать: ${esc(d.label.toLowerCase())}" data-color="${key}" value="${/^#[0-9a-f]{6}$/i.test(stringValue(value))?esc(value):'#2563eb'}" ${dis(key)}><input type="text" ${attributes} value="${esc(value)}" spellcheck="false"></div>`;
 else control=`<input type="${['email','tel'].includes(d.type)?d.type:'text'}" ${attributes} value="${esc(value)}" autocomplete="off" ${['url','email'].includes(d.type)?'spellcheck="false" autocapitalize="none"':''}>`;
 return `<div class="field ${options.full?'full':''} ${d.width==='short'?'short':''}" data-field-wrap="${key}"><label for="${id}">${esc(d.label)}${d.required?'<span class="required" aria-hidden="true">*</span>':''}</label>${control}<p class="field-help" id="help-${key}">${esc(hint)}</p><p class="field-error" id="error-${key}">${esc(error)}</p></div>`;
}
function assetField(key){
 const d=FIELD[key],id=val(key),asset=assets.get(id),preview=asset?`<img src="${esc(asset.url)}" alt="">`:icon('picture');
 return `<div class="file-field" data-field-wrap="${key}"><span class="file-label">${esc(d.label)}</span><div class="file-picker"><div class="asset-thumb ${key==='favicon'?'favicon':''}">${preview}</div><div class="asset-description"><p class="asset-name">${esc(asset?.name||(id?'Файл выбран':'Файл не выбран'))}</p><div class="asset-actions"><button type="button" class="text-button" data-pick="${key}" ${dis(key)}>${id?'Заменить файл':'Выбрать файл'}</button>${id?`<button type="button" class="text-button" data-detach="${key}" ${dis(key)}>Убрать из настроек</button>`:''}</div><p class="field-help">${esc(d.help||'Изображение из файловой библиотеки.')}</p></div></div><input type="file" id="file-${key}" data-file="${key}" class="sr-only" tabindex="-1" aria-label="${esc(d.label)}" accept="${key==='favicon'?'image/png,image/x-icon,image/vnd.microsoft.icon,image/webp':'image/png,image/jpeg,image/webp'}" ${dis(key)}><p class="field-error" id="error-${key}">${esc(errors[key]||'')}</p></div>`;
}
function messengerField(){
 const values=val('messengers');
 if(!Array.isArray(values)||values.some(item=>!item||typeof item!=='object'||Array.isArray(item)||typeof item.label!=='string'||typeof item.url!=='string'))return note('В записи используется другой формат мессенджеров. Он сохранится без изменений. Редактирование доступно после проверки структуры.');
 const rows=values.map((item,index)=>`<div class="messenger-row"><div><label for="messenger-name-${index}">Название</label><input id="messenger-name-${index}" data-messenger="${index}" data-property="label" value="${esc(item.label)}" ${dis('messengers')}></div><div><label for="messenger-url-${index}">Ссылка</label><input id="messenger-url-${index}" data-messenger="${index}" data-property="url" value="${esc(item.url)}" spellcheck="false" ${dis('messengers')}></div><button class="button icon-button" data-remove-messenger="${index}" aria-label="Удалить мессенджер ${index+1}" ${dis('messengers')}>${icon('trash')}</button></div>`).join('');
 return `<div data-field-wrap="messengers">${rows||'<p class="help" style="margin-bottom:12px">Мессенджеры не добавлены.</p>'}<button type="button" class="button" data-add-messenger ${dis('messengers')}>${icon('plus')}Добавить мессенджер</button><p class="field-error" id="error-messengers">${esc(errors.messengers||'')}</p></div>`;
}
function section(title,description,body,id=''){return `<section class="form-section" ${id?`id="${id}"`:''}><div class="form-section-intro"><h3>${esc(title)}</h3><p>${esc(description)}</p></div><div class="form-section-body">${body}</div></section>`;}
function grid(keys){return `<div class="form-grid">${keys.map(entry=>typeof entry==='string'?field(entry):field(entry[0],entry[1])).join('')}</div>`;}
const quickGroups={company:['company_name','legal_name'],contacts:['phone','email'],footer:['footer_text','footer_disclaimer']};
function overviewRow(title,summary,action,group){
 const open=inlineGroup===group,allowed=quickGroups[group]?.some(isWritable);
 const body=open?`<div class="inline-form">${grid(quickGroups[group].map(key=>[key,{full:group==='footer'}]))}<p class="help">${group==='footer'?'Тексты в нижней части сайта.':'Здесь меняются только показанные поля.'} Кнопка «Сохранить» сохраняет все ваши правки в настройках.</p></div>`:'';
 const button=group?`<button class="text-button" data-inline="${group}" ${!allowed&&!open?'disabled':''} aria-label="${open?'Свернуть':`Изменить: ${title.toLowerCase()}`}" aria-expanded="${open}">${open?'Свернуть':'Изменить'}</button>`:action;
 return `<div class="setting-row ${open?'editing':''}" ${group?`id="row-${group}"`:''}><div class="row-heading">${title}</div><div class="row-summary">${summary}</div><div class="row-action">${button}</div>${body}</div>`;
}
function technical(){return `<details class="technical"><summary>${icon('chevron')}Служебная информация</summary><div class="technical-content"><p class="help">Системные параметры не изменяются в этом редакторе.</p><dl><dt>Профиль магазина</dt><dd>Управляется отдельно</dd><dt>Яндекс Метрика</dt><dd>Не настроена в демонстрационной записи</dd><dt>Диспетчер тегов</dt><dd>Не настроен в демонстрационной записи</dd><dt>Переводы</dt><dd>Сохраняются без изменений</dd><dt>Запись</dt><dd>Демонстрационная, не связана с базой данных</dd></dl></div></details>`;}
function overview(){
 const v=editor.values(),requisites=[v.inn&&`ИНН ${v.inn}`,v.kpp&&`КПП ${v.kpp}`,v.ogrn&&`ОГРН ${v.ogrn}`].filter(Boolean).join(' · ');
 return `<div class="page-heading"><div><h2>Общие настройки</h2><p>Основные сведения о магазине и быстрый переход к нужным настройкам.</p></div></div>
 <div class="settings-list">
 ${overviewRow('Компания',`<strong>${esc(v.company_name||'Название не указано')}</strong><span class="secondary">${esc(v.legal_name||'Юридическое наименование не указано')}</span>`,'','company')}
 ${overviewRow('Связь с покупателями',`${esc(v.phone)}<span class="secondary">${esc(v.email)}</span>`,'','contacts')}
 ${overviewRow('Реквизиты',`${esc(requisites||'ИНН, КПП и ОГРН не указаны')}<span class="secondary">${esc(v.vat_info||'Информация о НДС не указана')}</span>`,`<button class="text-button" data-route="company" data-focus="input-inn">Настроить ${icon('chevron')}</button>`)}
 ${overviewRow('Подвал сайта',`${esc(v.footer_text||'Описание не указано')}<span class="secondary">${esc(v.footer_disclaimer||'Примечание не указано')}</span>`,'','footer')}
 </div>
 <h3 class="section-caption">Оформление и представление сайта</h3><div class="settings-list">
 ${overviewRow('Оформление',`${v.logo?'Логотип выбран':'Логотип не выбран'}<span class="secondary">Логотип, изображения, цвета и основная кнопка</span>`,`<button class="text-button" data-route="appearance">Настроить ${icon('chevron')}</button>`)}
 ${overviewRow('Поиск и соцсети',`Заголовки, описания и обложка ссылки<span class="secondary">Применение на сайте пока не подключено</span>`,`<button class="text-button" data-route="search">Настроить ${icon('chevron')}</button>`)}
 </div>${technical()}<p class="footnote">Изменения на сайте могут появляться с задержкой из-за кеширования. Неподключённые параметры отмечены рядом с полями.</p>`;
}
function companyPage(){return `<div class="page-heading"><div><h2>Компания</h2><p>Название магазина и юридические сведения — без смешения с контактами покупателей.</p></div></div>
 ${section('Название и организация','Эти сведения используются в разных частях сайта.',grid([['company_name',{full:true}],['legal_name',{full:true}]]))}
 ${section('Реквизиты','ИНН, КПП и ОГРН отображаются на странице «Контакты». Юридический адрес не заменяет адрес офиса.',`<div class="tax-grid">${['inn','kpp','ogrn'].map(key=>field(key)).join('')}</div>${grid([['legal_address',{full:true}],['vat_info',{full:true}]])}<details class="subdetails"><summary>Ссылки на документы</summary>${note('Эти ссылки сохраняются в настройках, но пока не выводятся на сайт.',true)}${grid([['requisites_url',{full:true}],['documents_url',{full:true}]])}</details>`,'requisites')}`;}
function contactsPage(){return `<div class="page-heading"><div><h2>Контакты</h2><p>Сведения, по которым покупатели могут связаться с вашей компанией.</p></div></div>
 ${section('Связь с покупателями','Проверьте телефон и почту перед сохранением.',grid(['phone','email']))}
 ${section('Адрес и доставка','Адрес офиса не обязательно совпадает с юридическим адресом.',grid([['address',{full:true}],'city','working_hours',['delivery_region',{full:true}]]))}
 ${section('Мессенджеры и социальные сети','Дополнительные способы связи.',`${note('Мессенджеры и социальные сети пока не выводятся на сайт.',true)}${messengerField()}<details class="subdetails"><summary>Социальные сети</summary><p class="help">Текущие данные сохраняются без изменений. Редактирование этого поля будет доступно после подтверждения его структуры — техническая форма здесь не показывается.</p></details>`)}`;}
function appearancePage(){return `<div class="page-heading"><div><h2>Оформление</h2><p>Собственные изображения, цвета и тексты магазина.</p></div></div>
 ${section('Логотип и изображения','Здесь выбираются файлы, а не создаётся новый фирменный стиль.',`${note('Сейчас логотип и изображения на витрине заданы в коде. Эти настройки пока не заменяют их на сайте.',true)}${['logo','favicon','company_image'].map(assetField).join('')}<p class="help" style="margin-top:16px">В этом макете файл остаётся в браузере. В Directus используется штатная файловая библиотека. Удаляется только связь, не сам файл.</p>`)}
 ${section('Цвета и основная кнопка','Не меняют оформление административной панели.',`${note('Цвета и основная кнопка ещё не подключены к этим настройкам. Изменения можно подготовить, но сейчас они не появятся на сайте.',true)}${grid(['primary_color','accent_color'])}${grid(['primary_cta_text','primary_cta_url'])}`)}
 ${section('Подвал сайта','Эти тексты уже используются в нижней части страниц.',grid([['footer_text',{full:true}],['footer_disclaimer',{full:true}]]))}`;}
function searchPreview(){const v=editor.values();return `<div class="preview"><small>example.test</small><h4>${esc(v.seo_title||v.company_name||'Название магазина')}</h4><p>${esc(v.seo_description||'Описание появится здесь после заполнения поля.')}</p><p class="preview-caption">Пример по введённому тексту. Это не фактическая поисковая выдача.</p></div>`;}
function sharePreview(){const v=editor.values(),asset=assets.get(v.default_og_image);return `<div class="preview">${asset?`<img src="${esc(asset.url)}" alt="">`:''}<small>example.test</small><h4>${esc(v.og_title||v.company_name||'Название магазина')}</h4><p>${esc(v.og_description||'Описание появится здесь после заполнения поля.')}</p><p class="preview-caption">Локальный пример карточки ссылки, не проверка публикации в социальной сети.</p></div>`;}
function searchPage(){return `<div class="page-heading"><div><h2>Поиск и соцсети</h2><p>Общие заголовки, описания и оформление ссылки на магазин.</p></div></div>
 ${note('Настройки этого раздела ещё не подключены к публичному сайту. Сейчас заголовки и описания берутся из отдельных страниц или кода витрины.',true)}
 ${section('Поисковая выдача','Значения по умолчанию для сайта. Индивидуальные настройки страниц редактируются отдельно.',`${grid([['seo_title',{full:true}],['seo_description',{full:true}]])}<div class="button-row" style="margin-top:16px"><button class="button" data-preview="search" aria-expanded="${previewSearch}">${previewSearch?'Скрыть пример':'Показать пример'}</button></div><div id="search-preview">${previewSearch?searchPreview():''}</div>`)}
 ${section('Карточка ссылки','Текст и изображение при отправке ссылки в мессенджере или социальной сети.',`${grid([['og_title',{full:true}],['og_description',{full:true}]])}<div style="margin-top:20px">${assetField('default_og_image')}</div><button class="button" data-preview="share" style="margin-top:18px" aria-expanded="${previewShare}">${previewShare?'Скрыть пример':'Показать пример'}</button><div id="share-preview">${previewShare?sharePreview():''}</div>`)}`;}
function blockedView(){
 const states={denied:['Нет доступа к настройкам','Для просмотра нужны права на настройки сайта. Обратитесь к администратору.'],loadError:['Не удалось загрузить настройки','Данные не получены. Проверьте подключение и повторите загрузку.'],missing:['Запись настроек не найдена','Раздел работает с одной существующей записью. Автоматическое создание запрещено. Обратитесь к администратору.'],multiple:['Найдено несколько записей настроек','Редактирование заблокировано: невозможно безопасно выбрать единственную запись. Обратитесь к администратору.']};
 const [title,text]=states[mode];return `<section class="empty-state"><h2>${title}</h2><p>${text}</p>${mode==='loadError'?'<button class="button primary" data-retry-load>Повторить загрузку</button>':''}</section>`;
}
function renderNav(){
 const dirty=editor.dirtyFields(),blocked=['denied','loadError','missing','multiple'].includes(mode);
 $('#section-nav').innerHTML=TABS.map(([key,label])=>{const has=key!=='overview'&&dirty.some(field=>FIELD[field].group===key);return `<button data-route="${key}" ${route===key?'aria-current="page"':''} ${blocked?'disabled':''}>${label}${has?'<span class="dirty-dot" aria-hidden="true"></span><span class="sr-only">, есть несохранённые изменения</span>':''}</button>`;}).join('');
}
function syncControls(){
 const count=editor.dirtyFields().length,phase=editor.status(),active=count>0||['saving','conflict','uncertain'].includes(phase);
 $('#savebar').hidden=!active;document.body.classList.toggle('has-dirty',active);
 $('#about-button').hidden=active&&matchMedia('(min-width:900px)').matches;
 $('#dirty-status').textContent=phase==='saving'?'Сохраняем…':phase==='conflict'?'Нужна сверка':phase==='uncertain'?'Ответ не подтверждён':`${count} ${count===1?'изменение':count<5?'изменения':'изменений'}`;
 $('#save-button').disabled=!editor.canSave();$('#discard-button').disabled=['saving','conflict','uncertain'].includes(phase);
 $('#save-button').innerHTML=phase==='saving'?'<span class="spinner" aria-hidden="true"></span>Сохраняем…':'Сохранить';
 // Do not rebuild focused tabs during input: update their markers in place.
 $$('#section-nav [data-route]').forEach(button=>{const key=button.dataset.route,has=key!=='overview'&&editor.dirtyFields().some(field=>FIELD[field].group===key);const marker=$('.dirty-dot',button);if(has&&!marker)button.insertAdjacentHTML('beforeend','<span class="dirty-dot" aria-hidden="true"></span><span class="sr-only">, есть несохранённые изменения</span>');if(!has&&marker){marker.remove();$('.sr-only',button)?.remove();}});
}
function renderView(){
 const blocked=['denied','loadError','missing','multiple'].includes(mode);
 $('#view').innerHTML=blocked?blockedView():({overview,company:companyPage,contacts:contactsPage,appearance:appearancePage,search:searchPage}[route]||overview)();
 if(!blocked&&mode==='readonly')$('#view').insertAdjacentHTML('afterbegin',note('Доступен только просмотр. Нет прав на изменение настроек.'));
 if(!blocked&&mode==='partial')$('#view').insertAdjacentHTML('afterbegin',note('В этом сценарии разрешено менять только телефон. Остальные поля доступны для просмотра.'));
 mountIcons();syncControls();
}
function render(){renderNav();renderView();renderProblem();}
function renderProblem(){
 const holder=$('#global-alert');
 if(Object.keys(errors).length){holder.innerHTML=`<section class="alert-box" tabindex="-1" id="validation-summary"><h3>Проверьте заполнение полей</h3><ul>${Object.entries(errors).map(([key,error])=>`<li><a href="#input-${key}" data-error-link="${key}">${esc(FIELD[key]?.label||'Поле')}: ${esc(error)}</a></li>`).join('')}</ul></section>`;return;}
 if(!problem){holder.innerHTML='';return;}
 if(problem==='network'){holder.innerHTML=`<section class="alert-box"><h3>Не удалось отправить изменения</h3><p>В этом сценарии запрос не ушёл. Ваши правки остаются в форме.</p><button class="button" data-retry-save>Повторить сохранение</button></section>`;return;}
 if(problem==='uncertain'){holder.innerHTML=`<section class="alert-box"><h3>Результат сохранения не подтверждён</h3><p>Ответ потерян. Данные могли сохраниться. Сначала проверьте результат — повторная отправка отключена.</p><button class="button" data-check-result>Проверить результат</button></section>`;return;}
 const compare=comparedRecord?`<div class="compare-list">${editor.dirtyFields().map(key=>`<div class="compare-item"><strong>${esc(FIELD[key].label)}</strong><div class="compare-options"><label><input type="radio" name="choice-${key}" value="local" checked><span><small>Мой вариант</small>${esc(formatValue(key,val(key)))}</span></label><label><input type="radio" name="choice-${key}" value="remote"><span><small>Сохранено другим сотрудником</small>${esc(formatValue(key,comparedRecord[key]))}</span></label></div></div>`).join('')}</div><button class="button" data-apply-compare>Применить выбор</button><p class="help" style="margin:12px 0 0">Выбор не отправляет данные автоматически. После проверки нажмите «Сохранить».</p>`:`<button class="button" data-open-compare>Сравнить изменения</button>`;
 holder.innerHTML=`<section class="alert-box"><h3>Другой сотрудник изменил настройки</h3><p>Ваши правки не потеряны. Сверьте их с сохранёнными данными перед повторным сохранением.</p>${compare}</section>`;
}
function navigate(next,focusKey=null){
 if(!TABS.some(([key])=>key===next))return;
 if(editor.status()==='saving'){toast('Дождитесь завершения сохранения.');return;}
 route=next;inlineGroup=null;render();closeMenu(false);
 if(focusKey){const input=$(`#${CSS.escape(focusKey)}`);input?.closest('details')?.setAttribute('open','');input?.focus();input?.scrollIntoView({block:'center',behavior:'instant'});}
 else {window.scrollTo({top:0,behavior:'instant'});const active=$(`#section-nav [data-route="${next}"]`);active?.focus({preventScroll:true});active?.scrollIntoView({inline:'nearest',block:'nearest',behavior:'instant'});}
}
function showFieldError(key){
 if(!$(`#input-${CSS.escape(key)}`)){route=FIELD[key]?.group||'overview';inlineGroup=null;render();}
 const input=$(`#input-${CSS.escape(key)}`)||$(`[data-field-wrap="${CSS.escape(key)}"] button`);
 input?.closest('details')?.setAttribute('open','');input?.focus();input?.scrollIntoView({block:'center',behavior:'instant'});
}
function toast(text){clearTimeout(toastTimer);$('#toast').textContent=text;$('#toast').hidden=false;toastTimer=setTimeout(()=>{$('#toast').hidden=true;},5200);}
async function save(){
 if(!editor.canSave())return;
 errors=validateValues(editor.values(),editor.baseline(),editor.dirtyFields());
 if(Object.keys(errors).length){renderView();renderProblem();$('#validation-summary')?.focus();return;}
 const inlineOrigin=inlineGroup,focusOrigin=editor.dirtyFields().find(key=>$(`[data-field="${key}"]`));
 const payload=editor.payload(),action=outcome;outcome='success';$('#demo-outcome').value='success';
 if(!editor.beginSave())return;problem=null;comparedRecord=null;renderView();renderProblem();
 await new Promise(resolve=>setTimeout(resolve,360));
 if(action==='network'){editor.fail();problem='network';render();return;}
 if(action==='conflict'){
  const key=Object.keys(payload.changes)[0];
  remoteRecord.updated_at=`demo-${++version}`;
  remoteRecord[key]=key==='phone'?'+7 (000) 222-22-22':key==='email'?'changed@example.test':FIELD[key]?.type==='file'?null:FIELD[key]?.type==='color'?'#334455':FIELD[key]?.type==='url'?'https://example.test/updated':key==='messengers'?[{label:'Другой канал',url:'https://example.test'}]:`${stringValue(remoteRecord[key])} (правка сотрудника)`;
  editor.conflict();problem='conflict';render();return;
 }
 if(payload.expected.updated_at!==remoteRecord.updated_at){editor.conflict();problem='conflict';render();return;}
 remoteRecord={...remoteRecord,...copy(payload.changes),updated_at:`demo-${++version}`};
 if(action==='uncertain'){editor.uncertain();problem='uncertain';render();return;}
 const ok=editor.acknowledge(remoteRecord);problem=ok?null:'uncertain';
 if(ok){inlineGroup=null;errors={};render();
  const focusTarget=inlineOrigin?$(`[data-inline="${inlineOrigin}"]`):focusOrigin?$(`[data-field="${focusOrigin}"]`):null;
  focusTarget?.focus({preventScroll:true});toast('Сохранено в макете. Публичный сайт не изменён.');}
 else render();
}
function confirmChanges(action,message='Все несохранённые правки будут отменены. Сохранённые значения останутся без изменений.'){
 confirmAction=action;confirmFocus=document.activeElement;$('#confirm-message').textContent=message;$('#confirm-dialog').showModal();$('#confirm-no').focus();
}
function discard(){
 if(!editor.dirtyFields().length||['saving','conflict','uncertain'].includes(editor.status()))return;
 confirmChanges(()=>{editor.discard();errors={};problem=null;inlineGroup=null;render();toast('Несохранённые изменения отменены.');});
}
function closeAbout(){if($('#about-dialog').open)$('#about-dialog').close();aboutFocus?.focus();}
function openAbout(){aboutFocus=document.activeElement;$('#demo-mode').value=mode;$('#demo-outcome').value=outcome;$('#about-dialog').showModal();$('#about-close').focus();}
function resetModel(nextMode='normal',nextOutcome='success'){
 remoteRecord=copy(INITIAL);version=1;mode=nextMode;outcome=nextOutcome;
 editor=createEditor(remoteRecord,nextMode==='partial'?['phone']:EDITABLE);editor.setReadonly(nextMode==='readonly');
 route='overview';inlineGroup=null;errors={};problem=null;comparedRecord=null;render();window.scrollTo(0,0);
}
function applyDemo(){
 const nextMode=$('#demo-mode').value,nextOutcome=$('#demo-outcome').value;closeAbout();
 if(nextMode===mode){outcome=nextOutcome;toast('Сценарий для следующего сохранения выбран.');return;}
 const apply=()=>resetModel(nextMode,nextOutcome);
 if(editor.dirtyFields().length)confirmChanges(apply,'Смена демонстрационного сценария сбросит все несохранённые правки.');else apply();
}
function openMenu(){
 $('#sidebar').classList.add('open');$('#menu-backdrop').classList.add('open');$('#sidebar').setAttribute('role','dialog');$('#sidebar').setAttribute('aria-modal','true');$('#app').inert=true;$('#open-menu').setAttribute('aria-expanded','true');document.body.style.overflow='hidden';$('#close-menu').focus();
}
function closeMenu(returnFocus=true){
 if(!$('#sidebar').classList.contains('open'))return;
 $('#sidebar').classList.remove('open');$('#menu-backdrop').classList.remove('open');$('#sidebar').removeAttribute('role');$('#sidebar').removeAttribute('aria-modal');$('#app').inert=false;$('#open-menu').setAttribute('aria-expanded','false');document.body.style.overflow='';if(returnFocus)$('#open-menu').focus();
}
function changedInput(target){
 const key=target.dataset.field;if(!key)return;
 // Empty optional scalar inputs retain null rather than creating an accidental empty-string edit.
 const raw=target.value,value=raw===''&&!FIELD[key].required&&editor.baseline()[key]===null?null:raw;
 if(!editor.change(key,value))return;
 if(errors[key]){delete errors[key];target.setAttribute('aria-invalid','false');$(`#error-${key}`).textContent='';renderProblem();}
 if(FIELD[key].type==='color'){const picker=$(`[data-color="${key}"]`);if(picker&&/^#[0-9a-f]{6}$/i.test(raw))picker.value=raw;}
 syncControls();
 if(previewSearch&&$('#search-preview'))$('#search-preview').innerHTML=searchPreview();
 if(previewShare&&$('#share-preview'))$('#share-preview').innerHTML=sharePreview();
}
document.addEventListener('input',event=>{
 const target=event.target;
 if(target.matches('[data-field]'))changedInput(target);
 if(target.matches('[data-color]')){const input=$(`[data-field="${target.dataset.color}"]`);input.value=target.value;changedInput(input);}
 if(target.matches('[data-messenger]')){
  const list=val('messengers');if(!Array.isArray(list)||!isWritable('messengers'))return;
  const index=Number(target.dataset.messenger);list[index]={...list[index],[target.dataset.property]:target.value};editor.change('messengers',list);delete errors.messengers;syncControls();renderProblem();
 }
});
document.addEventListener('change',event=>{
 const target=event.target;if(!target.matches('[data-file]'))return;
 const key=target.dataset.file,file=target.files?.[0];if(!file||!isWritable(key))return;
 const accepted=key==='favicon'?['image/png','image/x-icon','image/vnd.microsoft.icon','image/webp']:['image/png','image/jpeg','image/webp'];
 if(!accepted.includes(file.type)||file.size>10*1024*1024){errors[key]='Для макета выберите подходящее изображение до 10 МБ.';render();return;}
 // Asset UUID mirrors a relation field; no file bytes are stored in the settings payload.
 const id=typeof crypto.randomUUID==='function'?crypto.randomUUID():`00000000-0000-4000-8000-${String(++selectedAsset).padStart(12,'0')}`;
 assets.set(id,{name:file.name,url:URL.createObjectURL(file)});editor.change(key,id);delete errors[key];renderView();$(`[data-pick="${key}"]`)?.focus();toast('Файл выбран только в браузере. Загрузка на сервер не выполнялась.');
});
document.addEventListener('click',async event=>{
 const button=event.target.closest('button,a');if(!button||button.disabled)return;
 if(button.dataset.route){event.preventDefault();navigate(button.dataset.route,button.dataset.focus);}
 if(button.dataset.inline){
  const group=button.dataset.inline;if(editor.status()==='saving')return;
  inlineGroup=inlineGroup===group?null:group;renderView();
  if(inlineGroup)$(`[data-field="${quickGroups[group][0]}"]:not(:disabled)`)?.focus();else $(`[data-inline="${group}"]`)?.focus();
 }
 if(button.dataset.errorLink){event.preventDefault();showFieldError(button.dataset.errorLink);}
 if(button.dataset.pick)$(`#file-${button.dataset.pick}`)?.click();
 if(button.dataset.detach){editor.change(button.dataset.detach,null);renderView();$(`[data-pick="${button.dataset.detach}"]`)?.focus();}
 if(button.hasAttribute('data-add-messenger')){const rows=val('messengers');if(Array.isArray(rows)&&isWritable('messengers')){rows.push({label:'',url:''});editor.change('messengers',rows);renderView();$(`#messenger-name-${rows.length-1}`)?.focus();}}
 if(button.hasAttribute('data-remove-messenger')){const rows=val('messengers');if(Array.isArray(rows)&&isWritable('messengers')){rows.splice(Number(button.dataset.removeMessenger),1);editor.change('messengers',rows);renderView();$('[data-add-messenger]')?.focus();}}
 if(button.dataset.preview){if(button.dataset.preview==='search')previewSearch=!previewSearch;else previewShare=!previewShare;renderView();$(`[data-preview="${button.dataset.preview}"]`)?.focus();}
 if(button.hasAttribute('data-retry-save'))save();
 if(button.hasAttribute('data-retry-load')){mode='normal';render();toast('Демонстрационная загрузка завершена.');}
 if(button.hasAttribute('data-open-compare')){comparedRecord=copy(remoteRecord);renderProblem();$('[data-apply-compare]')?.focus();}
 if(button.hasAttribute('data-apply-compare')){
  const choices=Object.fromEntries(editor.dirtyFields().map(key=>[key,$(`input[name="choice-${key}"]:checked`)?.value]));
  if(editor.rebase(comparedRecord,choices)){comparedRecord=null;problem=null;errors={};render();toast(editor.dirtyFields().length?'Варианты сверены. Проверьте изменения и нажмите «Сохранить».':'Приняты сохранённые значения.');}
 }
 if(button.hasAttribute('data-check-result')){button.disabled=true;await new Promise(resolve=>setTimeout(resolve,240));if(editor.checkRemote(remoteRecord)){problem=null;errors={};inlineGroup=null;render();toast('Проверено: изменения сохранились в макете. Повторной отправки не было.');}else{problem='conflict';render();}}
});
$('#save-button').addEventListener('click',save);$('#discard-button').addEventListener('click',discard);
$('#about-button').addEventListener('click',openAbout);$('#about-close').addEventListener('click',closeAbout);$('#about-dialog').addEventListener('close',()=>aboutFocus?.focus());
$('#confirm-no').addEventListener('click',()=>{$('#confirm-dialog').close();confirmAction=null;confirmFocus?.focus();});
$('#confirm-yes').addEventListener('click',()=>{const action=confirmAction;confirmAction=null;$('#confirm-dialog').close();action?.();confirmFocus?.isConnected&&confirmFocus.focus();});
$('#confirm-dialog').addEventListener('cancel',()=>{confirmAction=null;confirmFocus?.focus();});
$('#apply-demo').addEventListener('click',applyDemo);
$('#reset-demo').addEventListener('click',()=>{closeAbout();if(editor.dirtyFields().length)confirmChanges(()=>resetModel());else resetModel();});
$('#open-menu').addEventListener('click',openMenu);$('#close-menu').addEventListener('click',()=>closeMenu());$('#menu-backdrop').addEventListener('click',()=>closeMenu());
document.addEventListener('keydown',event=>{
 if($('#sidebar').classList.contains('open')){
  if(event.key==='Escape'){event.preventDefault();closeMenu();}
  if(event.key==='Tab'){
   const focusable=$$('button:not(:disabled)', $('#sidebar')),first=focusable[0],last=focusable.at(-1);
   if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
   else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  }
 }
 if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();if(!document.querySelector('dialog[open]'))save();}
});
window.addEventListener('beforeunload',event=>{if(editor.dirtyFields().length||['saving','uncertain'].includes(editor.status())){event.preventDefault();event.returnValue='';}});
window.addEventListener('resize',()=>{syncControls();if(matchMedia('(min-width:900px)').matches)closeMenu(false);});
render();
