from playwright.sync_api import sync_playwright
import json

def lum(rgb):
    channels=[v/255 for v in rgb]
    return sum((c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4)*w for c,w in zip(channels,[.2126,.7152,.0722]))

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1536,'height':1024})
    page.set_content(__import__('pathlib').Path('/mnt/data/A5_redesign_v2/A5_settings_redesign_v2.html').read_text(), wait_until='load')
    color=page.locator('.card-sub').first.evaluate('(el)=>getComputedStyle(el).color')
    rgb=list(map(int,color.removeprefix('rgb(').removesuffix(')').split(',')))
    ratio=1.05/(lum(rgb)+.05)
    results=[{'requirement':'Readable supporting text: contrast >= 4.5:1','actual':round(ratio,2),'pass':ratio>=4.5}]
    page.locator('[data-open="legal"]').click()
    opened=page.locator('dialog[open]').count()
    results.append({'requirement':'Full requisites form is not in overlay drawer','open_dialogs':opened,'pass':opened==0})
    print(json.dumps(results,ensure_ascii=False,indent=2))
    browser.close()
