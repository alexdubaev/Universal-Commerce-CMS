import test from 'node:test';
import assert from 'node:assert/strict';
import {createEditor} from '../src/model.mjs';
const sample=()=>({id:'demo-singleton',updated_at:'demo-1',company_name:'Пример',phone:'+7 (000) 000-00-00',email:'office@example.test',inn:null,logo:null,messengers:[{label:'Телеграм',url:'https://example.test',unknown:{keep:true}}],commerce_profile:{private:'untouched'},translations:{future:'keep'}});
const allowed=['company_name','phone','email','inn','logo','messengers'];
test('Only changed allowed values enter the save; unknown data survive',()=>{
 const e=createEditor(sample(),allowed);assert.equal(e.change('company_name','Новый магазин'),true);
 assert.equal(e.change('commerce_profile',{}),false);
 assert.deepEqual(e.payload().changes,{company_name:'Новый магазин'});
 assert.equal(e.payload().expected.company_name,'Пример');
 assert.equal(e.payload().expected.updated_at,'demo-1');
 assert.deepEqual(e.values().messengers,sample().messengers);
});
test('Edits from different groups coexist until explicit save or cancel',()=>{
 const e=createEditor(sample(),allowed);e.change('phone','+7 (000) 111-11-11');e.change('inn','1234567890');
 assert.equal(e.dirtyFields().length,2);e.discard();assert.equal(e.dirtyFields().length,0);assert.equal(e.values().inn,null);
});
test('Acknowledgement must confirm every changed field and the same identity',()=>{
 const e=createEditor(sample(),allowed);e.change('company_name','Новое');e.beginSave();
 assert.equal(e.acknowledge({id:'wrong',updated_at:'demo-2',company_name:'Новое'}),false);
 assert.equal(e.status(),'uncertain');assert.equal(e.values().company_name,'Новое');assert.equal(e.canSave(),false);
});
test('A conflict preserves edits and rebase applies only an explicit choice',()=>{
 const e=createEditor(sample(),allowed);e.change('phone','Мой телефон');e.conflict();
 const remote={...sample(),updated_at:'demo-2',phone:'Чужой телефон',email:'new@example.test'};
 e.rebase(remote,{phone:'local'});assert.equal(e.values().phone,'Мой телефон');assert.equal(e.values().email,'new@example.test');
 assert.equal(e.payload().expected.phone,'Чужой телефон');assert.equal(e.payload().expected.updated_at,'demo-2');assert.equal(e.canSave(),true);
});
test('Uncertain commit is checked, never resent; exact remote state confirms it',()=>{
 const e=createEditor(sample(),allowed);e.change('phone','Изменено');e.beginSave();e.uncertain();assert.equal(e.canSave(),false);
 assert.equal(e.checkRemote({...sample(),updated_at:'demo-2',phone:'Изменено'}),true);assert.equal(e.dirtyFields().length,0);assert.equal(e.status(),'idle');
});
test('Readonly and saving states cannot mutate the draft',()=>{
 const e=createEditor(sample(),allowed);e.setReadonly(true);assert.equal(e.change('phone','new'),false);
 e.setReadonly(false);e.change('phone','new');e.beginSave();assert.equal(e.change('phone','newer'),false);
});
test('Successful save checks all changed fields then adopts the returned baseline',()=>{
 const e=createEditor(sample(),allowed);e.change('email','new@example.test');e.beginSave();
 assert.equal(e.acknowledge({...sample(),email:'new@example.test',updated_at:'demo-2'}),true);
 assert.equal(e.dirtyFields().length,0);assert.equal(e.values().email,'new@example.test');
});
