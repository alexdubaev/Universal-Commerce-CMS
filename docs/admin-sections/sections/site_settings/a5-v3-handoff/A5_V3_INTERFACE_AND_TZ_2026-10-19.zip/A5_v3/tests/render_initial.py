from pathlib import Path
import os, shutil
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
html=(root/'A5_settings_v3.html').read_text()
results=[]
with sync_playwright() as p:
    binary=os.environ.get('A5_CHROMIUM') or shutil.which('chromium') or shutil.which('google-chrome')
    browser=p.chromium.launch(**({'executable_path':binary} if binary else {}),headless=True,args=['--no-sandbox'])
    for label,width,height in [('desktop',1536,1024),('laptop',1024,768),('mobile',390,844),('small-mobile',320,720)]:
        page=browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        page.set_content(html,wait_until='load');page.screenshot(path=str(root/f'screenshots/{label}_overview.png'))
        results.append({'screen':label,'errors':errors,'overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth')})
        if label in ['desktop','mobile']:
            page.locator('#section-nav [data-route="contacts"]').click()
            page.screenshot(path=str(root/f'screenshots/{label}_contacts.png'))
            page.locator('#section-nav [data-route="company"]').click()
            page.screenshot(path=str(root/f'screenshots/{label}_company.png'))
            page.locator('#section-nav [data-route="appearance"]').click()
            page.screenshot(path=str(root/f'screenshots/{label}_appearance.png'))
            page.locator('#section-nav [data-route="overview"]').click()
            page.locator('[data-inline="contacts"]').click()
            page.locator('[data-field="phone"]').fill('+7 (000) 111-11-11')
            page.screenshot(path=str(root/f'screenshots/{label}_quick_edit.png'))
        page.close()
    browser.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
