"""Focused user journeys on the offline prototype, not Directus runtime tests."""
from pathlib import Path
import os, shutil
from playwright.sync_api import sync_playwright, expect
import json, re
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'A5_settings_v3.html').read_text()
results=[]
console_errors=[]
external_requests=[]
contrast_results=[]

def record(name,fn):
    try:
        fn();results.append({'scenario':name,'status':'PASS'})
    except Exception as e:
        results.append({'scenario':name,'status':'FAIL','error':str(e)});raise

def load(page):
    page.set_content(HTML,wait_until='load')
    page.evaluate('window.scrollTo(0,0)')

def route(page,name):
    page.locator(f'#section-nav [data-route="{name}"]').click()

def scenario(page,mode='normal',outcome='success'):
    page.locator('#about-button').click()
    page.locator('#about-dialog summary').click()
    page.select_option('#demo-mode',mode)
    page.select_option('#demo-outcome',outcome)
    page.locator('#apply-demo').click()

CONTRAST=r'''() => {
 const rgb=s=>(s.match(/[\d.]+/g)||[]).slice(0,3).map(Number);
 const lum=c=>c.map(x=>x/255).map(x=>x<=.04045?x/12.92:Math.pow((x+.055)/1.055,2.4)).reduce((a,x,i)=>a+x*[.2126,.7152,.0722][i],0);
 const rows=[];
 for(const e of document.querySelectorAll('#app *,.sidebar *')){
  const st=getComputedStyle(e),r=e.getBoundingClientRect();
  if(!r.width||!r.height||st.visibility==='hidden'||e.closest('[hidden]')||e.matches(':disabled')||e.classList.contains('sr-only'))continue;
  const text=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent.trim()).join('');
  if(!text)continue;
  let b=e,bg;
  while(b){const c=getComputedStyle(b).backgroundColor;if(c!=='rgba(0, 0, 0, 0)'&&c!=='transparent'){bg=rgb(c);break;}b=b.parentElement;}
  bg=bg||[255,255,255];const fg=rgb(st.color);if(fg.length!==3)continue;
  const a=lum(fg),z=lum(bg),ratio=(Math.max(a,z)+.05)/(Math.min(a,z)+.05);
  const large=parseFloat(st.fontSize)>=24||(parseFloat(st.fontSize)>=18.667&&parseInt(st.fontWeight)>=700);
  rows.push({text:text.slice(0,70),size:st.fontSize,ratio:Math.round(ratio*100)/100,passes:ratio>=(large?3:4.5)});
 }
 return rows;
}'''
with sync_playwright() as p:
    binary=os.environ.get('A5_CHROMIUM') or shutil.which('chromium') or shutil.which('google-chrome')
    browser=p.chromium.launch(**({'executable_path':binary} if binary else {}),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1536,'height':1024})
    page.on('pageerror',lambda e:console_errors.append(str(e)))
    page.on('request',lambda r:external_requests.append(r.url) if re.match(r'https?://',r.url) else None)
    load(page)
    def quick():
        assert not page.locator('#open-menu').is_visible()
        page.locator('[data-inline="contacts"]').click()
        assert page.locator('dialog[open]').count()==0
        page.locator('[data-field="phone"]').fill('+7 (000) 111-11-11')
        assert page.locator('#row-contacts .row-summary').is_hidden()
        page.locator('#save-button').click()
        expect(page.locator('#savebar')).to_be_hidden()
        expect(page.locator('#row-contacts')).to_contain_text('+7 (000) 111-11-11')
    record('Quick phone edit happens inline and saves the new summary',quick)
    load(page)
    def cross_group():
        route(page,'company');page.locator('#input-company_name').fill('Новый магазин')
        route(page,'contacts');page.locator('#input-phone').fill('+7 (000) 555-55-55')
        route(page,'company');expect(page.locator('#input-company_name')).to_have_value('Новый магазин')
        expect(page.locator('#dirty-status')).to_contain_text('2')
        page.locator('#save-button').click();expect(page.locator('#savebar')).to_be_hidden()
        route(page,'overview');expect(page.locator('#view')).to_contain_text('Новый магазин');expect(page.locator('#view')).to_contain_text('+7 (000) 555-55-55')
    record('Changes survive switching sections and share one save',cross_group)
    load(page)
    def cancel():
        route(page,'company');page.locator('#input-company_name').fill('Ошибка')
        page.locator('#discard-button').click();expect(page.locator('#confirm-dialog')).to_be_visible()
        page.locator('#confirm-no').click();expect(page.locator('#input-company_name')).to_have_value('Ошибка')
        page.locator('#discard-button').click();page.locator('#confirm-yes').click()
        expect(page.locator('#input-company_name')).to_have_value('Магазин запчастей')
    record('Cancel requires confirmation; continuing keeps the draft',cancel)
    load(page)
    def validation():
        route(page,'contacts');page.locator('#input-email').fill('не-почта')
        page.locator('#save-button').click();expect(page.locator('#validation-summary')).to_be_visible()
        expect(page.locator('#input-email')).to_have_attribute('aria-invalid','true')
        page.locator('[data-error-link="email"]').click();expect(page.locator('#input-email')).to_be_focused()
        page.locator('#input-email').fill('correct@example.test');page.locator('#save-button').click()
        expect(page.locator('#savebar')).to_be_hidden()
    record('Validation locates the invalid email and supports correction',validation)
    load(page)
    def conflict():
        scenario(page,outcome='conflict');route(page,'contacts');page.locator('#input-phone').fill('+7 (000) 333-33-33');page.locator('#save-button').click()
        expect(page.locator('[data-open-compare]')).to_be_visible();expect(page.locator('#input-phone')).to_have_value('+7 (000) 333-33-33')
        expect(page.locator('#save-button')).to_be_disabled();page.locator('[data-open-compare]').click()
        expect(page.locator('.compare-list')).to_contain_text('+7 (000) 222-22-22')
        page.screenshot(path=str(ROOT/'screenshots/desktop_conflict.png'))
        page.locator('[data-apply-compare]').click();expect(page.locator('#save-button')).to_be_enabled()
        expect(page.locator('#input-phone')).to_have_value('+7 (000) 333-33-33')
        page.locator('#save-button').click();expect(page.locator('#savebar')).to_be_hidden()
    record('Conflict keeps local input and requires comparison before another save',conflict)
    load(page)
    def uncertain():
        scenario(page,outcome='uncertain');route(page,'company');page.locator('#input-company_name').fill('Сохранено без ответа');page.locator('#save-button').click()
        expect(page.locator('[data-check-result]')).to_be_visible();expect(page.locator('#save-button')).to_be_disabled()
        page.locator('[data-check-result]').click();expect(page.locator('#savebar')).to_be_hidden()
        expect(page.locator('#input-company_name')).to_have_value('Сохранено без ответа')
        expect(page.locator('#toast')).to_contain_text('Повторной отправки не было')
    record('Lost save response is reconciled without resubmitting',uncertain)
    load(page)
    def roles():
        scenario(page,mode='readonly');route(page,'company');expect(page.locator('#input-company_name')).to_be_disabled();expect(page.locator('#savebar')).to_be_hidden()
        load(page);scenario(page,mode='partial');route(page,'contacts');expect(page.locator('#input-phone')).to_be_enabled();expect(page.locator('#input-email')).to_be_disabled()
        page.locator('#input-phone').fill('Только телефон');page.locator('#save-button').click();expect(page.locator('#savebar')).to_be_hidden()
    record('Readonly and field-limited roles restrict editing',roles)
    load(page)
    def failed_load():
        scenario(page,mode='loadError');expect(page.locator('.empty-state')).to_contain_text('Не удалось загрузить')
        page.locator('[data-retry-load]').click();expect(page.locator('#view')).to_contain_text('Общие настройки')
        for mode,text in [('missing','не найдена'),('multiple','несколько'),('denied','Нет доступа')]:
            load(page);scenario(page,mode=mode);expect(page.locator('.empty-state')).to_contain_text(text)
            assert page.locator('#view input').count()==0
    record('Load failures and invalid singleton cardinality never offer creation',failed_load)
    load(page)
    def asset():
        route(page,'appearance')
        page.locator('#file-logo').set_input_files({'name':'test.png','mimeType':'image/png','buffer':(ROOT/'screenshots/mobile_overview.png').read_bytes()})
        expect(page.locator('[data-field-wrap="logo"] .asset-name')).to_have_text('test.png')
        page.locator('#save-button').click();expect(page.locator('#savebar')).to_be_hidden()
        page.locator('[data-detach="logo"]').click();expect(page.locator('[data-field-wrap="logo"] .asset-name')).to_have_text('Файл не выбран')
    record('Image selection uses a local preview; detaching does not delete a file',asset)
    load(page)
    def full_forms():
        for name in ['company','contacts','appearance','search']:
            route(page,name);assert page.locator('dialog[open]').count()==0
            assert not page.evaluate('document.documentElement.scrollWidth>innerWidth')
            rows=page.evaluate(CONTRAST);contrast_results.extend(rows)
        assert not [r for r in contrast_results if not r['passes']], [r for r in contrast_results if not r['passes']]
    record('Full forms stay in the page; visible informative text meets contrast thresholds',full_forms)
    mobile=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,device_scale_factor=1,has_touch=True)
    mobile.on('pageerror',lambda e:console_errors.append(str(e)))
    load(mobile)
    def mobile_flow():
        mobile.locator('#open-menu').click();expect(mobile.locator('#sidebar')).to_have_attribute('aria-modal','true')
        mobile.keyboard.press('Escape');expect(mobile.locator('#open-menu')).to_be_focused()
        route(mobile,'contacts');mobile.locator('#input-phone').fill('+7 (000) 999-99-99')
        assert mobile.locator('#input-phone').evaluate('(e)=>parseFloat(getComputedStyle(e).fontSize)')>=16
        box=mobile.locator('#save-button').bounding_box();assert box['height']>=44 and box['y']+box['height']<=844
        mobile.locator('#save-button').click();expect(mobile.locator('#savebar')).to_be_hidden()
        for width,height in [(320,720),(390,844),(1024,768)]:
            mobile.set_viewport_size({'width':width,'height':height})
            for name in ['overview','company','appearance']:
                route(mobile,name);assert not mobile.evaluate('document.documentElement.scrollWidth>innerWidth'),(width,name)
    record('Mobile navigation, save action, readable fields and responsive reflow',mobile_flow)
    assert not console_errors,console_errors
    assert not external_requests,external_requests
    results.append({'scenario':'No browser JavaScript errors and no external HTTP requests','status':'PASS'})
    browser.close()
report={'surface':'Offline HTML prototype; not Directus runtime','results':results,'contrast_minimum':min(r['ratio'] for r in contrast_results),'contrast_pairs_tested':len(contrast_results),'console_errors':console_errors,'external_http_requests':external_requests}
(ROOT/'tests/browser-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
