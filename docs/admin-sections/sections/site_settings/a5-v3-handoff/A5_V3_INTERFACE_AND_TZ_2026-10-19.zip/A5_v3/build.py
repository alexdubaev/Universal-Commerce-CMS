"""Build a single offline HTML artifact; no dependencies or network access required."""
from pathlib import Path
root=Path(__file__).resolve().parent
code=[]
for name in ['model.mjs','config.mjs','app.js']:
    text=(root/'src'/name).read_text(encoding='utf-8')
    text='\n'.join(line for line in text.splitlines() if not line.startswith('import '))
    text=text.replace('export function ','function ').replace('export const ','const ')
    code.append(text)
html=(root/'src/index.html').read_text().replace('/* STYLES */',(root/'src/styles.css').read_text()).replace('/* SCRIPT */',"'use strict';\n(()=>{\n"+'\n\n'.join(code)+'\n})();')
output=root/'A5_settings_v3.html'
output.write_text(html,encoding='utf-8')
print(output, output.stat().st_size)
