"""Check only the offline A3 design prototype. No CMS/API/production access.

Usage: python check_reference.py --out /path/to/artifacts
Requires an installed Playwright Python package and Chromium.
Uses page.set_content() for offline rendering, not a running Directus.
"""
from __future__ import annotations
import argparse, json, os, re, shutil, subprocess, hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--out',type=Path,default=ROOT)
parser.add_argument('--chromium',default=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome'))
args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
HTML=(ROOT/'pages-reference.html').read_text(encoding='utf-8')
results=[]; errors=[]; network=[]; shots=[]
def check(name, test):
    ok=bool(test); results.append({'name':name,'status':'PASS' if ok else 'FAIL'});print(('PASS' if ok else 'FAIL'),name)
    if not ok: raise AssertionError(name)

with sync_playwright() as pw:
    browser=pw.chromium.launch(**({'executable_path':args.chromium} if args.chromium else {}),headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1536,'height':1024},device_scale_factor=1)
    def fresh(state=''):
        p=context.new_page();p.set_default_timeout(4000)
        p.on('pageerror',lambda e:errors.append(str(e)))
        p.on('request',lambda r:network.append(r.url))
        html=HTML.replace('new URLSearchParams(location.hash.slice(1))','new URLSearchParams('+json.dumps(state)+')')
        p.set_content(html);return p
    p=fresh()
    check('Список: один H1 и 9 синтетических строк',p.locator('h1').count()==1 and p.locator('tbody tr').count()==9)
    check('Первая строка desktop расположена в верхней трети',p.locator('tbody tr').first.bounding_box()['y']<300)
    p.locator('#search').fill('компании');check('Поиск по названию',p.locator('tbody tr').count()==2)
    p.locator('#search').fill('payment');check('Поиск по slug',p.locator('tbody tr').count()==1)
    p.locator('#search').fill('Как оплатить');check('Поиск по H1',p.locator('tbody tr').count()==1)
    p.locator('#search').fill('');p.locator('#status-filter').select_option('draft');check('Статус фильтрует строки',p.locator('tbody tr').count()==3)
    p.locator('#status-filter').select_option('');p.locator('#filters').click();p.locator('#filter-type').select_option('standard')
    check('Pending фильтр не изменяет выдачу',p.locator('tbody tr').count()==9)
    p.get_by_role('button',name='Отмена',exact=True).click();p.locator('#filters').click();check('Отмена не сохраняет pending выбор',p.locator('#filter-type').input_value()=='')
    p.keyboard.press('Escape');check('Escape закрывает модальное окно',not p.locator('#dialog').is_visible());check('Фокус возвращается кнопке',p.locator('#filters').evaluate('e=>e===document.activeElement'))
    p.locator('#filters').click();p.locator('#filter-type').select_option('standard');p.get_by_role('button',name='Применить',exact=True).click();check('Применение фильтра типа',p.locator('tbody tr').count()==3)
    check('Активный фильтр имеет удаляемую метку',p.locator('[data-clear="type"]').count()==1)
    p.locator('[data-clear="type"]').click();check('Удаление метки восстанавливает список',p.locator('tbody tr').count()==9)
    p.locator('#filters').click();p.locator('#filter-index').select_option('false');p.get_by_role('button',name='Применить',exact=True).click();check('Фильтр noindex',p.locator('tbody tr').count()==1)
    p.locator('#clear-extra').click();p.locator('#sort').select_option('title');first=p.locator('[data-open]').first.inner_text();p.locator('#sort').select_option('-title');check('Сортировка меняет порядок',first!=p.locator('[data-open]').first.inner_text())
    check('Все 10 вариантов сортировки доступны',p.locator('#sort option').count()==10)
    p.locator('#demo-mode').select_option('pagination');check('Пагинация: первая страница 25 строк',p.locator('tbody tr').count()==25)
    p.locator('#next').click();check('Пагинация: следующий ограниченный набор',p.locator('tbody tr').count()==7)
    p.close();p=fresh('view=editor&id=about')
    check('Карточка имеет 4 вкладки',p.locator('[role="tab"]').count()==4)
    p.locator('#p-title').fill('О компании — правка');p.locator('#tab-seo').click();p.locator('#tab-main').click();check('Ввод не теряется при смене вкладки',p.locator('#p-title').input_value()=='О компании — правка')
    p.locator('#back-list').click();check('Dirty guard показывает подтверждение',p.locator('#dialog-title').inner_text()=='Есть несохранённые изменения')
    p.get_by_role('button',name='Остаться',exact=True).click();check('Отмена ухода сохраняет ввод',p.locator('#p-title').input_value()=='О компании — правка')
    p.locator('#save-parent').click();check('Сохранение live-записи требует подтверждения',p.locator('#dialog-title').inner_text()=='Сохранить действующую страницу?')
    p.get_by_role('button',name='Сохранить поля страницы',exact=True).click();check('Parent save в памяти сбрасывает dirty',not p.evaluate('A3Demo.snapshot().dirty'))
    p.locator('#change-status').click();p.locator('#new-status').select_option('draft');p.get_by_role('button',name='Подтвердить статус',exact=True).click();check('Статус изменяется отдельным действием',p.evaluate('A3Demo.snapshot().current.status')=='draft')
    p.locator('#p-title').fill('Несохранённая правка родителя');p.locator('#tab-sections').click();p.locator('#s-text').fill('Правка одного блока');p.locator('#save-child').click();check('Child save не сохраняет parent',p.evaluate('A3Demo.snapshot().dirty') and not p.evaluate('A3Demo.snapshot().childDirty'))
    p.locator('#s-text').fill('Ещё одна правка блока');p.locator('#save-parent').click();check('Parent save не сохраняет child',not p.evaluate('A3Demo.snapshot().dirty') and p.evaluate('A3Demo.snapshot().childDirty'))
    p.close();p=fresh('view=new');p.locator('#p-title').fill('Новая обычная страница');p.locator('#save-parent').click();check('Required валидируются без потери title',p.locator('.validation-text').count()==1 and p.locator('#p-title').input_value()=='Новая обычная страница')
    p.locator('#p-slug').fill('about');p.locator('#p-h1').fill('Новая');p.locator('#save-parent').click();check('Дубликат slug не создаётся',p.locator('.validation-text').inner_text().find('уже есть')>=0)
    p.locator('#p-slug').fill('new-demo-page');p.locator('#save-parent').click();check('Новое создание остаётся draft',p.evaluate('A3Demo.snapshot().current.status')=='draft' and p.evaluate('A3Demo.snapshot().view')=='editor')
    p.locator('#tab-sections').click();check('Демоблоки не добавляются при создании',p.get_by_text('У страницы пока нет блоков',exact=True).count()==1)
    p.close();p=fresh('view=editor&id=about&state=readonly');check('Readonly блокирует редактирование и запись',p.locator('#p-title').is_disabled() and p.locator('#save-parent').is_disabled())
    p.close();p=fresh('view=editor&id=about&state=conflict');check('Конфликт сохраняет локальный ввод',p.locator('#p-h1').input_value()=='О компании — мой новый заголовок' and p.locator('#save-parent').is_disabled())
    p.locator('#compare').click();p.get_by_role('button',name='Оставить мой ввод',exact=True).click();check('Reconcile не выполняет автоматический save',p.evaluate('A3Demo.snapshot().dirty') and p.locator('#p-h1').input_value()=='О компании — мой новый заголовок')
    p.close();p=fresh('view=editor&id=about&tab=seo');p.locator('#p-seo_title').fill('Новый SEO-заголовок');check('Схематичный сниппет обновляется',p.locator('#snippet-title').inner_text()=='Новый SEO-заголовок')
    p.locator('#pick-image').click();p.get_by_role('button',name='Показать выбор в макете',exact=True).click();check('Медиа: демонстрация выбранного состояния',p.evaluate('A3Demo.snapshot().current.og_image')=='demo-image-only')
    p.locator('#remove-image').click();check('Медиа: отвязка только в памяти',p.evaluate('A3Demo.snapshot().current.og_image') is None)
    p.close();p=fresh('view=editor&id=home-source');check('Источник home не редактируется как обычная страница',p.locator('#p-title').is_disabled())
    p.close()
    screenshot_specs=[('pages-list-desktop.png',1536,1024,''),('pages-editor-desktop.png',1536,1024,'view=editor&id=about'),('pages-sections-desktop.png',1536,1024,'view=editor&id=about&tab=sections'),('pages-seo-desktop.png',1536,1024,'view=editor&id=about&tab=seo'),('pages-create-desktop.png',1536,1024,'view=new'),('pages-list-mobile.png',390,844,''),('pages-editor-mobile.png',390,844,'view=editor&id=about'),('pages-sections-mobile.png',390,844,'view=editor&id=about&tab=sections&detail=1'),('pages-conflict-desktop.png',1536,1024,'view=editor&id=about&state=conflict'),('pages-long-desktop.png',1536,1024,'state=long')]
    for name,w,h,state in screenshot_specs:
        p=fresh(state);p.set_viewport_size({'width':w,'height':h})
        check('Нет document overflow: '+name,p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        p.screenshot(path=str(args.out/name),full_page=False);shots.append({'file':name,'width':w,'height':h,'state':state});p.close()
    for w in [320,430,1024]:
        p=fresh('view=editor&id=about');p.set_viewport_size({'width':w,'height':844});check('Responsive editor '+str(w),p.evaluate('document.documentElement.scrollWidth<=innerWidth'));p.close()
    p=fresh();p.locator('#filters').click();p.screenshot(path=str(args.out/'pages-filters-desktop.png'))
    p.keyboard.press('Tab');check('Модальная панель удерживает фокус',p.locator('#dialog').evaluate('e=>e.contains(document.activeElement)'))
    p.set_viewport_size({'width':390,'height':844});check('Фильтры mobile без overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth'));p.screenshot(path=str(args.out/'pages-filters-mobile.png'));p.close()
    p=fresh('view=editor&id=about&tab=sections&detail=1');p.set_viewport_size({'width':390,'height':844});p.locator('#back-blocks').click();check('Mobile: возврат к списку блоков',p.locator('.sections-sidebar').is_visible() and not p.locator('.section-form').is_visible());p.locator('[data-section="s2"]').click();check('Mobile: открытие другого блока',p.locator('#s-title').input_value()=='Ответы на частые вопросы');p.close()
    check('Нет uncaught JavaScript errors',len(errors)==0)
    check('Нет сетевых запросов к CMS или внешним ресурсам',len(network)==0)
    version=browser.version;browser.close()
report={'scope':'OFFLINE_HTML_ONLY_NOT_DIRECTUS','approval':'PENDING_OWNER_REVIEW','source_html_sha256':hashlib.sha256(HTML.encode()).hexdigest(),'renderer':'Chromium via Playwright set_content (in-memory HTML)','chromium':version,'browser_connector':'Failed: originating browser context required','local_navigation':'file/http local navigation blocked by managed browser policy; no policy changes','checks':results,'pass':sum(r['status']=='PASS' for r in results),'fail':sum(r['status']=='FAIL' for r in results),'page_errors':errors,'network_requests':network,'screenshots':shots}
(args.out/'REFERENCE-QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'PASS':report['pass'],'FAIL':report['fail'],'browser':version},ensure_ascii=False))
