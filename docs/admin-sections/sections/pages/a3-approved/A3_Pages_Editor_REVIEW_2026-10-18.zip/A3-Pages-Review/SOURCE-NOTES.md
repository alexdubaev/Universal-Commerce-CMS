# Источники и границы исследования

Дата: 2026-10-18. Репозиторий Universal-Commerce-CMS, прочитанный main: `c594fd9ac874cd38cfb71abeedf932cfd785de55`.

Чтение через подключённый GitHub. Никаких write tools для репозитория не вызывалось.

- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/docs/admin-sections/sections/pages/TZ.md — назначение, маршруты, 4 вкладки, сохранение и scope.
- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/docs/admin-sections/sections/pages/fields.json — 18 полей и 9 значений page_type; статический snapshot.
- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/storefront/lib/content.ts — getCmsPage, fields, publication filter, чтение блоков.
- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/storefront/app/%5Bslug%5D/page.tsx — generic metadata и notFound.
- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/storefront/app/about/page.tsx — built-in fallback для /about.
- https://github.com/alexdubaev/Universal-Commerce-CMS/blob/c594fd9ac874cd38cfb71abeedf932cfd785de55/storefront/components/CmsPageRenderer.tsx — h1/intro/sections/seo_text, отсутствие вывода eyebrow в проверенном компоненте.

Визуальный источник: ранее одобренный пользователем пакет A2, `home-page-reference.html` и `home-hero-desktop.png`. Цвета/шрифт/оболочка/поля/вкладки переиспользованы. A3 новый экран согласования, не уже одобренный дизайн. Интерфейс списков продолжает описанное исправление A1-UI-FIX.

Не исследовались текущая БД, секреты, production и незавершённый worktree A2. Не утверждается, что A2 уже реализован. Ограничения native version/section контрактов взяты из ранее предоставленных A0/A1 handoff и одобренного A2 TASK; агент A3 должен сверить их с текущими принятыми exports.

Из старого pages/TZ не переносится ошибочный общий пункт о singleton: pages — не singleton. page_type не выдаётся за generator маршрутов. Подмена семантики «save live» на «draft save» запрещена.
