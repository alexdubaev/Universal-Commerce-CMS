# Поля и публичные маршруты A3

Снимок `c594fd9ac874cd38cfb71abeedf932cfd785de55`. Проверена документация 18 полей; live schema не проверялась. Названия/required/choices перед runtime сверить с Directus. Все URLs ниже — технические источники, не подтверждение текущего deployment.

| Поле | Где в UI | Связь с витриной / замечание |
|---|---|---|
| title | Основное, список | getCmsPage → breadcrumbs, metadata fallback |
| slug | Основное, список | Поиск опубликованной записи по точному slug; не автоматически новый router |
| page_type | Основное, фильтр | Native enum; обычный generic renderer не выбирает новый шаблон по этому полю |
| h1 | Основное | Заголовок в CmsPageRenderer, fallback title |
| eyebrow | Раскрываемое в Основном | Читается адаптером, в проверенном CmsPageRenderer не выводится |
| intro | Основное | Вступление в renderer и fallback description |
| status | Бейдж и отдельное действие | getCmsPage читает только published; fixed-route fallback может остаться |
| seo_title | SEO | Metadata страницы, fallback title |
| seo_description | SEO | Metadata, fallback intro |
| seo_text | SEO, «Текст внизу» | Выводится после блоков как текст, не HTML-builder |
| og_image | SEO, native picker | Metadata og image с существующим asset proxy |
| canonical_url | SEO, раскрываемое | Пропускается через safeCanonicalUrl |
| is_indexable | SEO, фильтр | robots noindex, также участвует в списке indexable pages; не подтверждает индексирование |
| seo | SEO, native plugin | В getCmsPage не запрашивается напрямую. Проверить hooks/projections, не утверждать JSON-first для всего frontend по старой заметке |
| translations | Дополнительно | В проверенном getCmsPage не читается; публичная локализация не обещается |
| id | Дополнительно readonly | Identity и связь блоков |
| created_at | Дополнительно readonly | Техническое поле, не фронтенд-контент |
| updated_at | Дополнительно readonly | CAS baseline; присутствует, null допустим для новой записи |

`page_sections` не новое поле content в pages: читается отдельной коллекцией с `page=<id>` и `home_page=null`. На вкладке используется общий A2/A0 controller. Alias не отправлять в parent save. Типы содержимого и JSON не перестраивать.

## Какие маршруты подтверждены статически

- `storefront/app/[slug]/page.tsx` читает `getCmsPage(slug)`; без опубликованной записи вызывает notFound. Это одноуровневый URL. Не обещать произвольные вложенные `/a/b`.
- `storefront/app/about/page.tsx` читает CMS `about`, но без записи возвращает свой built-in контент. Следовательно, «архивировать about» не равно выключить страницу /about.
- home — отдельное управление через A2 и `home_page`. Привязку source_page нельзя менять A3.
- delivery/contacts/payment и другие fixed routes: агент проверяет их фактические consumer paths перед заявлениями о видимости; названия в демотаблице не заменяют эту проверку.
- catalog/articles/brands/request/API/asset/sitemap routes: существующие системные поверхности. Не создавать для них новый публичный маршрут через смену page_type/slug.

## Правило проверки

Матрица для конкретной записи: запись → slug → есть ли fixed route → читает ли он pages → какие поля рендерит → что произойдёт при draft/archived → как обновляется кэш. Подтверждённый публичный GET не считать предпросмотром staged edits. Пропуск consumer означает ограничение, не скрытое разрешение менять storefront.

Старые документы предлагают возможные UI-маршруты. Их наличие на бумаге не означает регистрацию в текущем модуле; регистрируется только pages после приёмки.
